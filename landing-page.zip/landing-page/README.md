Front End Web DevelopmentProfessional Landing Page Project

Table of Contents

1- All features are usable across modern desktop, tablet, and phone browsers.

2- Styling has been added for active states.

3- There are 4 sections that have been added to the page.

4- Navigation is built dynamically.

5- It should be clear which section is being viewed while scrolling through the page.

6- When clicking an item from the navigation menu, the link  scroll to the appropriate section.

use two type function :-

1- Anonymous function in forEach List each item in the array with  like (links.forEach((del_link)=>)

 2- Normal function with paramter like (function SetActiveLink(secnav))


about me:-

my name is mohamed gamal metwally , 30 years old , Bachelor's degree in Information Systems , worked HR in cairo water company ,i want to shift my career to be a freelancer .


i want to thank Udacity and egypt Fwd to give me a chance to this scholarship and Udacity tutor Mohamed Hegazy to help me to pass landing Page in zoom meeting ,
and my class team in this track to support me .


guide :-
https://www.w3schools.com/
https://developer.mozilla.org/
