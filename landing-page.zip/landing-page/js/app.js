/**
 * 
 * Manipulating the DOM exercise.
 * Exercise programmatically builds navigation,
 * scrolls to anchors from navigation,
 * and highlights section in viewport upon scrolling.
 * 
 * Dependencies: None
 * 
 * JS Version: ES2015/ES6
 * 
 * JS Standard: ESlint
 * 
*/
/**
 * Define Global Variables
 * 
*/
 //declare Array sections  
const sections = document.querySelectorAll("section");
 //declare mymul to get ul by id= navbar__list
const mymul = document.getElementById("navbar__list");
 //declare fragment to Create a documentFragment node and append a child to it (a list item)
 //guide link https://www.w3schools.com/jsref/tryit.asp?filename=tryjsref_document_createdocfrag
const fragment = document.createDocumentFragment();

/**
 * End Global Variables
 * Start Helper Functions
 */ 
// Build menu 

// use forEach List each item in the array sections  pass  funcation CreateMenuD
//guide link https://www.w3schools.com/jsref/jsref_forEach.asp 
//https://www.w3schools.com/jsref/met_node_appendchild.asp
sections.forEach(CreateMenuD);
// function use to create list item 
function CreateMenuD(Element, index)
{
 //declare linktext to get text by data-nav in Array Sections
    let linktext = Element.getAttribute("data-nav");
//declare newlink to create Element Link
    let newlink = document.createElement("a");
//declare textnode to Create a text node
    let textnode = document.createTextNode(linktext);
//declare newli to Create a <li> node
    let newli = document.createElement("li");
// Append the text to <a>
    newlink.appendChild(textnode);
// Append <li> to <a> with let newlink
    newli.appendChild(newlink);
// create Event Listener to <a> newLink var 
        newlink.addEventListener("click",()=>
        { 
//scrollIntoView() method  is called is visible to the user . use behavior to transition animation.
            Element.scrollIntoView({behavior: "smooth"});
        })
// append a child fragment method <li> to (a list item) insted method
    fragment.appendChild(newli);
}
// append a child mymul <li> by fragment Array
mymul.appendChild(fragment);

/**
 * End Helper Functions
 * Begin Main Functions
 * 
*/

// build the nav

//https://developer.mozilla.org/en-US/docs/Web/API/Window
//https://developer.mozilla.org/en-US/docs/Web/API/Document/scroll_event
//The Window interface represents a window containing a DOM document; the document property points to the DOM document loaded in that window

// Scroll to section on link click
window.addEventListener("scroll",()=>
{
// use forEach List each item in the array with anonymous function
    sections.forEach((sec,index)=>
    {
/*getBoundingClientRect() method returns a DOMRect object providing 
information about the size of an element and its position relative */
// declare rect and assign the size and position of an element sec  
    const rect = sec.getBoundingClientRect(); 
        // use if to check position
        if (rect.top > 0 && rect.top < 200)
            {
            //declare secnav to get text by data-nav in Array Sections
            const secnav = sec.getAttribute("data-nav");

               // use forEach List each <section> in the array with anonymous function
                sections.forEach((active_sec)=>
                {
                     // Set background color sections as not active 
                     active_sec.style.background = "FloralWhite";
                })
            // Set background color section select as active 
            sec.style.background = "DarkGray";
            //Call function Set links active
            SetActiveLink(secnav);
            }
    });
    
    //create function Set links active   
    function SetActiveLink(secnav)
    {
     //declare Array <a> links 
    const links = document.querySelectorAll("a");
    // use forEach List each <a> in the array with anonymous function                
        links.forEach((alink)=>
        {
            // use if to check <a> text with  secnav to get text by data-nav in Array Sections
            if ( alink.innerText == secnav)
               {
                    // use forEach List each <a> in the array with anonymous function    
                     links.forEach((del_link)=>
                     {
                          // Set background color  list <a> as not active 
                        del_link.style.background = "black";
                     })
                // Set background color select <a> as  active 
                 alink.style.background = "orange";
                }
        })      
    }  
    
})

/**
 * End Main Functions
 * Begin Events
 * 
*/






